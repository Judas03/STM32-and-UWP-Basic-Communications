﻿/* Name - Aar Mhan Phyo 
    Student Id - 0268bk9c*/
using Communication_STM32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Communication_STM32
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {   // Initialize variables
        LeanComms Serial = new LeanComms(LeanComms.MbedDevice.F401RE);
        Boolean led_is_on = false;
        Boolean led_is_off = false;
        Boolean blinking = false;
        private DispatcherTimer timer;
        private int countdownSeconds;

        public MainPage()
        {
            this.InitializeComponent();
            Serial.NewSerialData += Serial_NewSerialData; // getting the data from mcu
            // Below command is to run the uwp in full screen
            //ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.FullScreen;


        }
        private void Serial_NewSerialData(NewDataArgs e)
        {
            Display.Text = e.NewData[0]; // display the data from the MCU
            blinking_led(e); // call the blinking function
            status_box(); // call the status function
            InitializeCountdownTimer(e); // call the countdown function
        }
        private void LED_ON_Click(object sender, RoutedEventArgs e)
        {

            Serial.WriteSerial("{\"LED\":\"Y\" }\r\n");
            led_is_on = true;
            led_is_off = false;
            blinking = false;
            status_box(); // call the status function
        }
        private void LED_OFF_Click(object sender, RoutedEventArgs e)
        {
            Serial.WriteSerial("{\"LED\":\"N\" }\r\n");
            led_is_on = false;
            led_is_off = true;
            blinking = false;
            status_box(); // call the status function 


        }
        private void blinking_led(NewDataArgs e)
        {
            if (e.NewData[0] == "Button Clicked!!!")
            {
                blinking = true;
                led_is_on = false;
                led_is_off = false;
                status_box(); // call the status function

            }

        }
        // Function to change color of the status box
        private void status_box()
        {
            if (led_is_on) // Trigger when the LED On button is clicked
            {
                on_led.Background = new SolidColorBrush(Windows.UI.Colors.Green);
                off_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
                blink_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
            }
            else if (led_is_off) // Trigger when the LED Off button is clicked
            {
                on_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
                off_led.Background = new SolidColorBrush(Windows.UI.Colors.Green);
                blink_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
            }
            else if (blinking) // trigger when the blinking button is clicked
            {
                on_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
                off_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
                blink_led.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            }
            else if(!blinking && !led_is_on && !led_is_on) // default state
            {
                on_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
                off_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
                blink_led.Background = new SolidColorBrush(Windows.UI.Colors.White);
            }


        }




        private void Display_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        //  function to start the countdown 
        private void InitializeCountdownTimer(NewDataArgs e)
        {
            if (e.NewData[0] == "Button Clicked!!!") // Trigger as soon as button clicked msg is recived from the MCU
            {
                countdownSeconds = 15; // Set the countdown time in seconds

                timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromSeconds(1);
                timer.Tick += Timer_Tick;
                timer.Start();
            }
        }

        // function to set up timer 
        private void Timer_Tick(object sender, object e)
        {
            if (countdownSeconds > 0)
            {
                countdownSeconds--; // reduce 1 seonds 
                countdown.Text = countdownSeconds.ToString(); // print the timer 
            }
            else
            {
                timer.Stop(); // stop the timer
                countdown.Text = "00:00"; // set back to default
                blink_led.Background = new SolidColorBrush(Windows.UI.Colors.White); // after the countdown set back the blinking box to default
                blinking = false; // to stop activating the blinking function for status box


            }
        }



    }
}
